# LiquidCrystal_I2C_ESP32

LiquidCrystal I2C Arduino library, with added method for rewiring SCL and SDA on ESP32 
